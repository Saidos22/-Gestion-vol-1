<?php
$SERVER='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect('localhost','root','','gestion des v');

if(!$connection){die("problem de connection".mysqli_connect_erro());}

$a = $_POST["id_vols"];
$b = $_POST["num_vols"];
$c = $_POST["Date_depart"];
$d = $_POST["Date_arrive"];
$e = $_POST["Heure_depart"];
$f = $_POST["Heure_arrive"];
$g = $_POST["id_aeroport_depart"];
$h = $_POST["id_aeroport_arrivee"];
$i = $_POST["id_avion"];


$A=("UPDATE vols SET id_vols = $a , num_vols = $b, Date_depart ='$c', Heure_depart = '$d',Date_arrive='$e',Heure_arrive='$f', id_aeroport_depart = $g,id_aeroport_arrivee = $h, id_avion = $i WHERE id_vols = $a");
if(mysqli_query($connection,$A)){
    echo "modification reussie";
}
else{
    echo "modification non reussie";
}