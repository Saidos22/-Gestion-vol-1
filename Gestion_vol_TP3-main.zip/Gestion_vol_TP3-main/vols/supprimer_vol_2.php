<?php
$server='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect($server,$utilisateur,$motpasse,$base);


$id_vol = $_POST["id_vol"];


$sql = "DELETE FROM vols WHERE id_vols = $id_vol";


if (mysqli_query($connection,$sql)) {
        echo "Vol Supprimer avec succés";
    } 
    
    else {
        echo "Erreur de suppression";
    }
     ?>