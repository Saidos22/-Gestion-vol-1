<?php
$SERVER='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';
$connection=mysqli_connect('localhost','root','','gestion des v');

if(!$connection){die("problem de connection".mysqli_connect_erro());}

$A=("SELECT * FROM vols");
$result=mysqli_query($connection,$A);
echo "<table border=8 cellspacing=0>
<tr>
<th>id_vols	</th>
<th>num_vols</th>
<th>Date_depart</th>
<th>Date_arrive</th>
<th>Heure_depart</th>
<th>Heure_arrive</th>
<th>id_aeroport_depart</th>
<th>id_aeroport_arrivee</th>
<th>id_avion</th>


</tr>
";
echo "<style>

.btnn:hover{
    background: #fff;
    color: #ff0000;
}

.btnn a{
    text-decoration: none;
    color: #000;
    font-weight: bold;
}";
 echo "</style>";
echo "<tr>";

if($result){
    while($row=mysqli_fetch_row($result)){
        echo "<td>".$row[0]."</td>";
        echo "<td>".$row[1]."</td>";
        echo "<td>".$row[2]."</td>";
        echo "<td>".$row[3]."</td>";
        echo "<td>".$row[4]."</td>";
        echo "<td>".$row[5]."</td>";
        echo "<td>".$row[6]."</td>";
        echo "<td>".$row[7]."</td>";
        echo "<td>".$row[8]."</td>";
       
       
        echo "</tr>";
    }
    echo "</table>";
    echo "<br>";
   echo "<button type= submit class=btnn> <a href='vol.html'> Revenir</button></a>";
}
else{
    echo "affichage echoue";
}
?>