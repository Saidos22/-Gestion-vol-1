<?php
$server='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect($server,$utilisateur,$motpasse,$base);
								

$a = $_POST["id_vols"];
$b = $_POST["num_vols"];
$c = $_POST["Date_depart"];
$d = $_POST["Date_arrive"];
$e = $_POST["Heure_depart"];
$f = $_POST["Heure_arrive"];
$g = $_POST["id_aeroport_depart"];
$h = $_POST["id_aeroport_arrivee"];
$i = $_POST["id_avion"];


// SQL query to insert data into the table

$sql = ("INSERT INTO vols VALUES ($a, $b, '$c', '$d','$e','$f',$g,$h,$i)");


if (mysqli_query($connection,$sql)) {
        echo "vol Ajouté";
    } else {
        echo "Erreur d'Ajout";
    }
     ?>

