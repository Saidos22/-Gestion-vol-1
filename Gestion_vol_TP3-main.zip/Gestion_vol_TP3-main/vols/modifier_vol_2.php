<!DOCTYPE html>
<html>
<head>
	<title>formulaire reservation</title>
</head>
<body> <div class="form">
<center>
	<style>

.btnn:hover{
    background: #fff;
    color: #ff0000;
}

.btnn a{
    text-decoration: none;
    color: #000;
    font-weight: bold;
}
 </style>
<h1>formulaire reservation</h1>


<form method="POST" action="modifier_vol_3.php">
	<table cellpadding="16">
     <?php 
          $serveur="localhost";
          $user="root";
          $secret="";
          $base="gestion des v";

               
          $sum=mysqli_connect($serveur,$user,$secret,$base);
          $num=$_POST["id_vol"];
          $result=mysqli_query($sum,"SELECT * FROM vols WHERE id_vols=$num");
	?>

  								

          <?php
          	while ($col=mysqli_fetch_row($result)) {

         ?>
		<tr>
			<td><b>id_vols</td>
			<td>
				<?php 

				echo"<input type='number' name='id_vols' value='$col[0]'>";
				 
				 ?>
			</td>
		</tr>
	
		<tr>
			<td><b>num_vols</td>        
			<td>
				<?php 

				echo"<input type='number' name='num_vols' value='$col[1]'>";
				 ?>
			</td>
		</tr>
		<tr>
			<td><b>Date_depart</td>
			<td><?php 

				echo"<input type='text' name='Date_depart' value='$col[2]'>";
				 ?> </td>
		</tr>

		<tr>
			<td><b>Heure_depart</td>
			<td><?php 

				echo"<input type='text' name='Heure_depart' value='$col[3]'>";
				 ?> </td>
		</tr>

		<tr>
			<td> <b>Date_arrive</td>
			<td><?php 

				echo"<input type='text' name='Date_arrive' value='$col[4]'>";
				 ?> </td>
                
		</tr>

		<tr>
			<td> <b>Heure_arrive</td>
			<td><?php 

				echo"<input type='text' name='Heure_arrive' value='$col[5]'>";
				 ?> </td>
                
		</tr>

		<tr>
			<td> <b>id_aeroport_depart</td>
			<td><?php 

				echo"<input type='number' name='id_aeroport_depart' value='$col[6]'>";
				 ?> </td>
                
		</tr>

		<tr>
			<td> <b>id_aeroport_arrivee</td>
			<td><?php 

				echo"<input type='number' name='id_aeroport_arrivee' value='$col[7]'>";
				 ?> </td>
                
		</tr>

		<tr>
			<td> <b>id_avion</td>
			<td><?php 

				echo"<input type='number' name='id_avion' value='$col[8]'>";}
				 ?> </td>
                
		</tr>
		
        <tr>
            
            <td><input type="submit" name="envoyer" value="Modifier"></td>
			<td><input type="reset" name="annuler" value="Annuler"></td>
			<td><button type="reset" class="btnn"><a href="vol.html">Revenir</a></button></td>
			
		</tr>
	</table>
</form>
</body>
</center>
</html>