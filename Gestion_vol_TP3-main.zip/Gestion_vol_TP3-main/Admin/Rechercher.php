 <?php
    $server='localhost';
    $utilisateur='root';
    $motpasse='';
    $base='gestion des v';
    
    $connection=mysqli_connect($server,$utilisateur,$motpasse,$base);
    $souba=$_POST['souba'];
   $result=mysqli_query($connection,"SELECT * FROM administrateurs WHERE Id_Admin='$souba'");
echo '<table border="9">
<tr>
  <th> Id_Admin : </th>
  <th> Prenom : </th>
  <th>Nom :</th>
  <th> Adresse :</th>
  <th>E_mail :</th>
  <th>Num_Tel :</th>
  <th>Poste :</th>
  <th>Mot_De_Passe :</th>
</tr>';


while($ligne=mysqli_fetch_row($result)) {
    echo '<tr>
    <td>'.$num=$ligne[0]. '</td>
    <td>'.$nom=$ligne[1]. '</td>
    <td>'.$pass=$ligne[2]. '</td>
    <td>'.$sexe=$ligne[3]. '</td>
    <td>'.$filiere=$ligne[4]. '</td>
    <td>'.$email=$ligne[5]. '</td>
    <td>'.$adresse=$ligne[6]. '</td>
    <td>'.$adresse=$ligne[7]. '</td>
    </tr>';
    }
  echo '</table>';


         ?>