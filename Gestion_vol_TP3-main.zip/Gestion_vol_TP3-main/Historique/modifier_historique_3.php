<?php
$SERVER='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect('localhost','root','','gestion des v');

if(!$connection){die("problem de connection".mysqli_connect_erro());}

$id=$_POST['id_historique'];
$classe=$_POST['Date_vol'];
$prix=$_POST['Statut_vol'];
$id_v=$_POST['id_vols'];    

$A=("UPDATE historique_vols SET id_historique = $id ,	Date_vol = '$classe', Statut_vol ='$prix', id_vols = $id_v  WHERE id_historique = $id");

if(mysqli_query($connection,$A)){
    echo "modification reussie";
}
else{
    echo "modification non reussie";
}