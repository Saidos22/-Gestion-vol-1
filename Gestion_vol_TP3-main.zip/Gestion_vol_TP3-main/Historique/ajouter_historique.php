<?php
$server='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect($server,$utilisateur,$motpasse,$base);


$a = $_POST["id_historique"];           
$b = $_POST["Date_vol"];
$c = $_POST["Statut_vol"];
$d = $_POST["id_vols"];

// SQL query to insert data into the table

$sql = ("INSERT INTO historique_vols VALUES ($a, '$b', '$c', $d)");


if (mysqli_query($connection,$sql)) {
        echo "Historique Ajouté";
    } else {
        echo "Erreur d'Ajout";
    }
     ?>

