<!DOCTYPE html>
<html>
<head>
	<title>formulaire Historique</title>
</head>
<style>

.btnn:hover{
    background: #fff;
    color: #ff0000;
}

.btnn a{
    text-decoration: none;
    color: #000;
    font-weight: bold;
}
 </style>
<body> <div class="form">
<center>
<h1>formulaire Historique</h1>


<form method="POST" action="modifier_historique_3.php">
	<table cellpadding="16">
     <?php 
          $serveur="localhost";
          $user="root";
          $secret="";
          $base="gestion des v";

               
          $sum=mysqli_connect($serveur,$user,$secret,$base);
          $num=$_POST["id_historique"];
          $result=mysqli_query($sum,"SELECT * FROM historique_vols WHERE id_historique=$num");
	?>
  
          <?php
          	while ($col=mysqli_fetch_row($result)) {

         ?>
		<tr>
			<td><b>id_historique</td>
			<td>
				<?php 

				echo"<input type='number' name='id_historique' value='$col[0]'>";
				 
				 ?>
			</td>
		</tr>
	
		<tr>
			<td><b>Date_vol</td>        
			<td>
				<?php 

				echo"<input type='text' name='Date_vol' value='$col[1]'>";
				 ?>
			</td>
		</tr>
		<tr>
			<td><b>Statut_vol</td>
			<td><?php 

				echo"<input type='text' name='Statut_vol' value='$col[2]'>";
				 ?> </td>
		</tr>
		<tr>
			<td> <b>id_vols</td>
			<td><?php 

				echo"<input type='number' name='id_vols' value='$col[3]'>";}
				 ?> </td>
                
		</tr>
		
        <tr>
            
            <td><input type="submit" name="envoyer" value="Modifier"></td>
			<td><input type="reset" name="annuler" value="Annuler"></td>
			<td><button type="reset" class="btnn"><a href="historique.html">Revenir</a></button></td>
			
		</tr>
	</table>
</form>
</body>
</center>
</html>