<?php
$server='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect($server,$utilisateur,$motpasse,$base);


$id_historique = $_POST["id_historique"];


$sql = "DELETE FROM historique_vols WHERE id_historique = $id_historique";


if (mysqli_query($connection,$sql)) {
        echo "Historique Supprimer avec succés";
    } 
    
    else {
        echo "Erreur de suppression";
    }
     ?>