<?php
$server='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect($server,$utilisateur,$motpasse,$base);

                                            
			
$a = $_POST["id_bagage"];
$b = $_POST["poids_du_bagage"];
$c = $_POST["statut_du_bagage"];
$d = $_POST["id_reservation"];

// SQL query to insert data into the table

$sql = ("INSERT INTO bagages VALUES ($a, '$b', '$c', $d)");


if (mysqli_query($connection,$sql)) {
        echo "bagage Ajouté";
    } else {
        echo "Erreur d'Ajout";
    }
     ?>

