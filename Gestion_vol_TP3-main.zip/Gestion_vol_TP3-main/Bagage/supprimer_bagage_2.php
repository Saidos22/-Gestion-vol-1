<?php
$server='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect($server,$utilisateur,$motpasse,$base);


$id_bagage = $_POST["id_bagage"];


$sql = "DELETE FROM bagages WHERE id_bagage = $id_bagage";


if (mysqli_query($connection,$sql)) {
        echo "Bagages Supprimer avec succés";
    } 
    
    else {
        echo "Erreur de suppression";
    }
     ?>