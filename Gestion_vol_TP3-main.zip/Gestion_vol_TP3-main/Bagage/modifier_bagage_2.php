<!DOCTYPE html>
<html>
<head>
	<title>formulaire Etudiant</title>
</head>
<body> <div class="form">
<center>
<h1>formulaire Etudiant</h1>


<form method="POST" action="modifier_bagage_3.php">
	<table cellpadding="16">
     <?php 
          $serveur="localhost";
          $user="root";
          $secret="";
          $base="gestion des v";

               
          $sum=mysqli_connect($serveur,$user,$secret,$base);
          $num=$_POST["id_bagage"];
          $result=mysqli_query($sum,"SELECT * FROM bagages WHERE id_bagage=$num");
	?>
  
          <?php
          	while ($col=mysqli_fetch_row($result)) {

         ?>

         <style>

.btnn:hover{
    background: #fff;
    color: #ff0000;
}

.btnn a{
    text-decoration: none;
    color: #000;
    font-weight: bold;
}
 </style>
		<tr>
			<td><b>id_bagage</td>
			<td>
				<?php 

				echo"<input type='number' name='id' value='$col[0]'>";
				 
				 ?>
			</td>
		</tr>

		<tr>
			<td><b>poids du bagage</td>        
			<td>
				<?php 

				echo"<input type='text' name='poid' value='$col[1]'>";
				 ?>
			</td>
		</tr>
		<tr>
			<td><b>statut_du_bagage</td>
			<td><?php 

				echo"<input type='text' name='statut' value='$col[2]'>";
				 ?> </td>
		</tr>
		<tr>
			<td> <b>id_reservation</td>
			<td><?php 

				echo"<input type='number' name='id_res' value='$col[3]'>";}
				 ?> </td>
                
		</tr>
		
        <tr>
            
            <td><input type="submit" name="envoyer" value="Modifier"></td>
			<td><input type="reset" name="annuler" value="Annuler"></td>
			<td><button type="submit" class="btnn"> <a href="interfaceB.html">Revenir</button></a></td>
		</tr>
	</table>
</form>
</body>
</center>
</html>