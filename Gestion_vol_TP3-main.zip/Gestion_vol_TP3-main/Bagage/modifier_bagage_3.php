<?php
$SERVER='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect('localhost','root','','gestion des v');

if(!$connection){die("problem de connection".mysqli_connect_erro());}

$id=$_POST['id'];
$poid=$_POST['poid'];
$statut=$_POST['statut'];
$id_res=$_POST['id_res'];

$A=("UPDATE bagages SET id_bagage = $id , 	poids_du_bagage = '$poid', statut_du_bagage ='$statut'	, id_reservation = $id_res  WHERE id_bagage = $id");
if(mysqli_query($connection,$A)){
    echo "modification reussie";
}
else{
    echo "modification non reussie";
}