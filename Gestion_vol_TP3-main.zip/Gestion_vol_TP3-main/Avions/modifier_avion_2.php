<!DOCTYPE html>
<html>
<head>
	<title>formulaire Etudiant</title>
</head>
<body> <div class="form">
<center>
<h1>formulaire Etudiant</h1>


<form method="POST" action="modifier_avion_3.php">
	<table cellpadding="16">
     <?php 
          $serveur="localhost";
          $user="root";
          $secret="";
          $base="gestion des v";

               
          $sum=mysqli_connect($serveur,$user,$secret,$base);
          $num=$_POST["id_avion"];
          $result=mysqli_query($sum,"SELECT * FROM avion WHERE id_avion=$num");
	?>
  
          <?php
          	while ($col=mysqli_fetch_row($result)) {

         ?>
		<tr>
			<td><b>id_avion</td>
			<td>
				<?php 

				echo"<input type='number' name='id' value='$col[0]'>";
				 
				 ?>
			</td>
		</tr>
	
		<tr>
			<td><b>num_identification</td>        
			<td>
				<?php 

				echo"<input type='number' name='num_i' value='$col[1]'>";
				 ?>
			</td>
		</tr>
		<tr>
			<td><b>Modele_avion</td>
			<td><?php 

				echo"<input type='text' name='modele' value='$col[2]'>";
				 ?> </td>
		</tr>
		<tr>
			<td> <b>capacite_avion</td>
			<td><?php 

				echo"<input type='text' name='capacite' value='$col[3]'>";}
				 ?> </td>
                
		</tr>
		 <style>

.btnn:hover{
    background: #fff;
    color: #ff0000;
}

.btnn a{
    text-decoration: none;
    color: #000;
    font-weight: bold;
}
 </style>
		
        <tr>
            
            <td><input type="submit" name="envoyer" value="Modifier"></td>
			<td><input type="reset" name="annuler" value="Annuler"></td>
			<td><button type="submit" class="btnn"> <a href="Interface.html">Revenir</button></a></td>
			
		</tr>
	</table>
</form>
</body>
</center>
</html>