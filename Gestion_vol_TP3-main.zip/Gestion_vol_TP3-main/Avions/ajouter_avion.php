<?php
$server='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect($server,$utilisateur,$motpasse,$base);



$b = $_POST["num_identification"];
$c = $_POST["Modele_avion"];
$d = $_POST["capacite_avion"];

// SQL query to insert data into the table

$sql = ("INSERT INTO avion VALUES (null, '$b', '$c', '$d')");


if (mysqli_query($connection,$sql)) {
        echo "avion Ajouté";
    } else {
        echo "Erreur d'Ajout";
    }
     ?>

