<?php
$SERVER='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect('localhost','root','','gestion des v');

if(!$connection){die("problem de connection".mysqli_connect_erro());}

$id=$_POST['id'];
$poid=$_POST['num_i'];
$statut=$_POST['modele'];
$id_res=$_POST['capacite'];    

$A=("UPDATE avion SET id_avion = $id , 	num_identification = $poid, modele_avion ='$statut'	, capacite_avion = '$id_res'  WHERE id_avion = $id");
if(mysqli_query($connection,$A)){
    echo "modification reussie";
}
else{
    echo "modification non reussie";
}