<?php
$server='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect($server,$utilisateur,$motpasse,$base);


$id_avion = $_POST["id_avion"];


$sql = "SELECT * FROM avion WHERE id_avion = $id_avion";

$result = mysqli_query($connection,$sql);


echo "<table border=8 cellspacing=0>
<tr>
<th>id_avion</th>
<th>num_identification</th>
<th>Modele_avion</th>
<th>Capacité_avion</th>


</tr>
";
echo "<tr>";
echo "<style>

.btnn:hover{
    background: #fff;
    color: #ff0000;
}

.btnn a{
    text-decoration: none;
    color: #000;
    font-weight: bold;
}";
 echo "</style>";

if($result){
    while($row=mysqli_fetch_row($result)){
        echo "<td>".$row[0]."</td>";
        echo "<td>".$row[1]."</td>";
        echo "<td>".$row[2]."</td>";
        echo "<td>".$row[3]."</td>";
       
       
        echo "</tr>";
    }
    echo "</table>";
    echo "<br>";
   echo "<button type= submit class=btnn> <a href='Interface.html'> Revenir</button></a>";
}
else{
    echo "affichage echoue";
}
     ?>