<?php
$server='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect($server,$utilisateur,$motpasse,$base);


$id_avion = $_POST["id_avion"];


$sql = "DELETE FROM avion WHERE id_avion = $id_avion";


if (mysqli_query($connection,$sql)) {
        echo "Avion Supprimer avec succés";
    } 
    
    else {
        echo "Erreur de suppression";
    }
     ?>