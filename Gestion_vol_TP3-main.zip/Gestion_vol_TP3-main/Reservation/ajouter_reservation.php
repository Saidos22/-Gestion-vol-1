<?php
$server='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect($server,$utilisateur,$motpasse,$base);


$a = $_POST['date_reservation'];				
$b = $_POST["numero_de_siege_reserve"];
$c = $_POST["statut_de_paiement"];
$d = $_POST["id_passager"];
$e = $_POST["id_vols"];

// SQL query to insert data into the table

$sql = ("INSERT INTO reservation 
(id_reservation,	
date_reservation,	
numero_de_siege_reserve,	
statut_de_paiement	,
id_passager	,
id_vols) VALUES (NULL,'$a', $b, '$c', '$d',$e)");


if (mysqli_query($connection,$sql)) {
        echo "reservation Ajouté";
    } else {
        echo "Erreur d'Ajout";
    }
     ?>

