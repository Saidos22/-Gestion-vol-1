<?php
$SERVER='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';
$connection=mysqli_connect('localhost','root','','gestion des v');

if(!$connection){die("problem de connection".mysqli_connect_erro());}

$A=("SELECT * FROM reservation");
$result=mysqli_query($connection,$A);
echo "<table border=8 cellspacing=0>
<tr>
<th>id_reservation</th>
<th>date_reservation</th>
<th>numero_de_siege_reserve</th>
<th>statut_de_paiement</th>
<th>id_passager</th>
<th>id_vols</th>
	
	
</tr>
";
echo "<style>

.btnn:hover{
    background: #fff;
    color: #ff0000;
}

.btnn a{
    text-decoration: none;
    color: #000;
    font-weight: bold;
}";
 echo "</style>";
echo "<tr>";

if($result){
    while($row=mysqli_fetch_row($result)){
        echo "<td>".$row[0]."</td>";
        echo "<td>".$row[1]."</td>";
        echo "<td>".$row[2]."</td>";
        echo "<td>".$row[3]."</td>";
        echo "<td>".$row[4]."</td>";
        echo "<td>".$row[5]."</td>";
       
       
        echo "</tr>";
    }
    echo "</table>";
     echo "<br>";
   echo "<button type= submit class=btnn> <a href='reserv.html'> Revenir</button></a>";
}
else{
    echo "affichage echoue";
}
?>