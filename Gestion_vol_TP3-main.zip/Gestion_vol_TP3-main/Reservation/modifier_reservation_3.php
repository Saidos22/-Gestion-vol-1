<?php
$SERVER='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect('localhost','root','','gestion des v');

if(!$connection){die("problem de connection".mysqli_connect_erro());}
$f = $_POST['id_reservation'];
$a = $_POST['date_reservation'];				
$b = $_POST["numero_de_siege_reserve"];
$c = $_POST["statut_de_paiement"];
$d = $_POST["id_passager"];
$e = $_POST["id_vols"];  

$A=("UPDATE reservation SET id_reservation = $f , 	date_reservation = '$a', numero_de_siege_reserve =$b	, statut_de_paiement = '$c', id_passager = '$d' , id_vols = $e WHERE id_reservation = $f");
if(mysqli_query($connection,$A)){
    echo "modification reussie";
}
else{
    echo "modification non reussie";
}