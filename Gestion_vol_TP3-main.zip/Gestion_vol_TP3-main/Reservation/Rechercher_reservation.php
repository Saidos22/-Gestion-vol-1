<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rechercher une reservation</title>
    
</head>
<style>
        body {
            font-family: Arial, sans-serif;
        }

        form {
            max-width: 400px;
            margin: 0 auto;
        }

        label, input {
            display: block;
            margin-bottom: 10px;
        }
    </style>
    <style>

.btnn:hover{
    background: #fff;
    color: #ff0000;
}

.btnn a{
    text-decoration: none;
    color: #000;
    font-weight: bold;
}
 </style>
<body>

    <center><h2>Rechercher un avion</h2></center>

    <center>
        
        <form action="Rechercher_reservation_2.php" method="post">
        <label >Sélectionnez la reservation à Rechercher :</label>
        <select name="id_reservation" required>
          
            <?php
            
            $server='localhost';
            $utilisateur='root';
            $motpasse='';
            $base='gestion des v';

            $connection=mysqli_connect($server,$utilisateur,$motpasse,$base);

            
            $sql = "SELECT id_reservation FROM reservation";
            $result = mysqli_query($connection,$sql);

           
            while ($row = mysqli_fetch_row($result)) {
                echo "<option>" . $row[0] . "</option>";
            }

        
            ?>
        </select>

        <button type="submit">Rechercher reservation</button>
        <button type="reset" class="btnn"><a href="reserv.html">Revenir</a></button>
    </form>

    </center>
    
</body>
</html>
