<?php
$server='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect($server,$utilisateur,$motpasse,$base);


$id_res = $_POST["id_reservation"];


$sql = "DELETE FROM reservation WHERE id_reservation = $id_res";


if (mysqli_query($connection,$sql)) {
        echo "reservation Supprimer avec succés";
    } 
    
    else {
        echo "Erreur de suppression";
    }
     ?>