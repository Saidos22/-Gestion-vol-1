<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="soubaneh2.css">
</head>
<body>
    <div class="main2"> <!--main -->
        <div class="couleur">
        <div class="navbar"><!--main/navbar -->
             <div class="menu"><!--main/navbar/menu -->
               <div class="top">
           <img class="img" src="dj.jpg" height="35px" width="50px" align="left">
                <center>  <ul>
                   <li><a href="soubaneh.html">Acceuil</a></li>
                   <li><a href="about.html">A Propros</a></li>
                   <li><a href="service.html">SERVICE</a></li>
                   <li><a href="contacte.html">CONTACT</a></li>
                </ul></center> 
                <img class="img" src="dj.jpg" height="35px" width="50px" align="right">
            </div>
               
             </div><!--main/navbar -->

                 <!--main/navbar -->

       </div> <!--main -->
       <div class="content"><!--main/content -->
           <h1><span>Connexion</span></h1>
         
         <style>

           .form {
            text-align: center;
            margin-left: 415px; 
           
            }
    
        </style>
           
<form action="test_admin.php" method="post">
               <div class="form">
                <h2>Login Here</h2>
                <input type="text" name="number" placeholder="Entrer Votre Identifiant Ici">
                <input type="password" name="mdp" placeholder="Entrer Votre Mot De Passe Ici">
                <button type="submit" class="btnn">Se Connecter</button>
                <button type="reset" class="btnn">Annuler</button>
                <button type="" class="btnn"><a href="soubaneh.html">Revenir</button></a>
</form>
               
             

                    <div class="icons">
                    <a href="#"><ion-icon name="logo-facebook"></ion-icon></a>
                    <a href="#"><ion-icon name="logo-instagram"></ion-icon></a>
                    <a href="#"><ion-icon name="logo-twitter"></ion-icon></a>
                    <a href="#"><ion-icon name="logo-google"></ion-icon></a>
                    <a href="#"><ion-icon name="logo-skype"></ion-icon></a>
                </div>

            </div>
        </div>
        
    </div>
</div>
             
                   </div><!--main -->
    
  
    


   
</body>
</html>