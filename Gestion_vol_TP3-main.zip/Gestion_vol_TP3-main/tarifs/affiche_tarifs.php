<?php
$SERVER='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';
$connection=mysqli_connect('localhost','root','','gestion des v');

if(!$connection){die("problem de connection".mysqli_connect_erro());}

$A=("SELECT * FROM tarifs");
$result=mysqli_query($connection,$A);
echo "<table border=8 cellspacing=0>
<tr>
<th>id_tarifs</th>
<th>classe_service</th>
<th>prix_billet</th>
<th>id_vol</th>


</tr>
";
echo "<style>

.btnn:hover{
    background: #fff;
    color: #ff0000;
}

.btnn a{
    text-decoration: none;
    color: #000;
    font-weight: bold;
}";
 echo "</style>";
echo "<tr>";

if($result){
    while($row=mysqli_fetch_row($result)){
        echo "<td>".$row[0]."</td>";
        echo "<td>".$row[1]."</td>";
        echo "<td>".$row[2]."</td>";
        echo "<td>".$row[3]."</td>";
       
       
        echo "</tr>";
    }
    echo "</table>";
     echo "<br>";
   echo "<button type= submit class=btnn> <a href='tari.html'> Revenir</button></a>";
}
else{
    echo "affichage echoue";
}
?>