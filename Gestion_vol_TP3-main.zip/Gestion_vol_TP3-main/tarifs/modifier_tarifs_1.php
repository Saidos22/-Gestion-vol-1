<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier un Tarifs</title>
    
</head>
<style>
        body {
            font-family: Arial, sans-serif;
        }

        form {
            max-width: 400px;
            margin: 0 auto;
        }

        label, input {
            display: block;
            margin-bottom: 10px;
        }
    </style>
    <style>

.btnn:hover{
    background: #fff;
    color: #ff0000;
}

.btnn a{
    text-decoration: none;
    color: #000;
    font-weight: bold;
}
 </style>
<body>

    <center><h2>Modifier un Tarifs</h2></center>

    <center>
        
        <form action="modifier_tarifs_2.php" method="post">
        <label >Sélectionnez le tarifs à Modifier :</label>
        <select name="id_tarif" required>
          
            <?php
            
            $server='localhost';
            $utilisateur='root';
            $motpasse='';
            $base='gestion des v';

            $connection=mysqli_connect($server,$utilisateur,$motpasse,$base);

            
            $sql = "SELECT id_tarif FROM tarifs";
            $result = mysqli_query($connection,$sql);

           
            while ($row = mysqli_fetch_row($result)) {
                echo "<option>" . $row[0] . "</option>";
            }

        
            ?>
        </select>

        <button type="submit">Modifier tarifs</button>
         <button type="reset" class="btnn"><a href="tari.html">Revenir</a></button>
    </form>

    </center>
    
</body>
</html>
