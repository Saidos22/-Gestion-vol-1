<?php
$server='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect($server,$utilisateur,$motpasse,$base);


$a = $_POST["ID_tarifs"];           
$b = $_POST["classe_service"];
$c = $_POST["prix_billet"];
$d = $_POST["id_vols"];

// SQL query to insert data into the table

$sql = ("INSERT INTO tarifs VALUES ($a, '$b', '$c', $d)");


if (mysqli_query($connection,$sql)) {
        echo "tarifs Ajouté";
    } else {
        echo "Erreur d'Ajout";
    }
     ?>

