<!DOCTYPE html>
<html>
<head>
	<title>formulaire Tarifs</title>
</head>
<body> <div class="form">
<center>
	<style>

.btnn:hover{
    background: #fff;
    color: #ff0000;
}

.btnn a{
    text-decoration: none;
    color: #000;
    font-weight: bold;
}
 </style>
<h1>formulaire Tarifs</h1>


<form method="POST" action="modifier_tarifs_3.php">
	<table cellpadding="16">
     <?php 
          $serveur="localhost";
          $user="root";
          $secret="";
          $base="gestion des v";

               
          $sum=mysqli_connect($serveur,$user,$secret,$base);
          $num=$_POST["id_tarif"];
          $result=mysqli_query($sum,"SELECT * FROM tarifs WHERE id_tarif=$num");
	?>
  
          <?php
          	while ($col=mysqli_fetch_row($result)) {

         ?>
		<tr>
			<td><b>id_tarif</td>
			<td>
				<?php 

				echo"<input type='number' name='id_tarif' value='$col[0]'>";
				 
				 ?>
			</td>
		</tr>
	
		<tr>
			<td><b>classe_service</td>        
			<td>
				<?php 

				echo"<input type='text' name='classe_service' value='$col[1]'>";
				 ?>
			</td>
		</tr>
		<tr>
			<td><b>prix_billet</td>
			<td><?php 

				echo"<input type='text' name='prix_billet' value='$col[2]'>";
				 ?> </td>
		</tr>
		<tr>
			<td> <b>id_vols</td>
			<td><?php 

				echo"<input type='number' name='id_vols' value='$col[3]'>";}
				 ?> </td>
                
		</tr>
		
        <tr>
            
            <td><input type="submit" name="envoyer" value="Modifier"></td>
			<td><input type="reset" name="annuler" value="Annuler"></td>
			<td><button type="reset" class="btnn"><a href="tari.html">Revenir</a></button></td>
			
		</tr>
	</table>
</form>
</body>
</center>
</html>