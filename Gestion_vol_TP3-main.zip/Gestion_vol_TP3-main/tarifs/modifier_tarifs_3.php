<?php
$SERVER='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect('localhost','root','','gestion des v');

if(!$connection){die("problem de connection".mysqli_connect_erro());}

$id=$_POST['id_tarif'];
$classe=$_POST['classe_service'];
$prix=$_POST['prix_billet'];
$id_v=$_POST['id_vols'];    

$A=("UPDATE tarifs SET id_tarif = $id ,	classe_service = '$classe', prix_billet ='$prix', id_vol = $id_v  WHERE id_tarif = $id");

if(mysqli_query($connection,$A)){
    echo "modification reussie";
}
else{
    echo "modification non reussie";
}