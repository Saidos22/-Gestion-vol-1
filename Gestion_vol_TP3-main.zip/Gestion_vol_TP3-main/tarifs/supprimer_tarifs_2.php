<?php
$server='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect($server,$utilisateur,$motpasse,$base);


$id_tarif = $_POST["id_tarif"];


$sql = "DELETE FROM tarifs WHERE id_tarif = $id_tarif";


if (mysqli_query($connection,$sql)) {
        echo "Tarifs Supprimer avec succés";
    } 
    
    else {
        echo "Erreur de suppression";
    }
     ?>