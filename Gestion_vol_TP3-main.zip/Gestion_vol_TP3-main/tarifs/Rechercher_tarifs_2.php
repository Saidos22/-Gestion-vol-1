<?php
$server='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect($server,$utilisateur,$motpasse,$base);


$id_tarif = $_POST["id_tarif"];


$sql = "SELECT * FROM tarifs WHERE id_tarif = $id_tarif";

$result = mysqli_query($connection,$sql);


echo "<table border=8 cellspacing=0>
<tr>
<th>id_tarif</th>
<th>classe_service</th>
<th>prix_billet</th>
<th>id_vols</th>


</tr>
";
echo "<style>

.btnn:hover{
    background: #fff;
    color: #ff0000;
}

.btnn a{
    text-decoration: none;
    color: #000;
    font-weight: bold;
}";
 echo "</style>";
echo "<tr>";

if($result){
    while($row=mysqli_fetch_row($result)){
        echo "<td>".$row[0]."</td>";
        echo "<td>".$row[1]."</td>";
        echo "<td>".$row[2]."</td>";
        echo "<td>".$row[3]."</td>";
       
       
        echo "</tr>";
    }
    echo "</table>";
    echo "<br>";
   echo "<button type= submit class=btnn> <a href='tari.html'> Revenir</button></a>";
}
else{
    echo "affichage echoue";
}
     ?>