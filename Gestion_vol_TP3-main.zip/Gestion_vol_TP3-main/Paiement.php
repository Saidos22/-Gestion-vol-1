<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
</head>

<body>
    <div class="main">
        <div class="couleur">

<header> <center><h1 ><span>Paiement</span></h1></center> </header>
    
       <div class="content"><!--main/content -->
           
<?php
           session_start();

// Vérifier si l'username est défini dans la session
if(isset($_SESSION['username'])) {
    // Utiliser l'username
    $username = $_SESSION['username'];
    $vol = $_SESSION['vol'];
    $date_d = $_SESSION['date_d'];
    $heure_d = $_SESSION['heure_d'];
    $ville_arriv = $_SESSION['ville_arriv'] ;
    $siege = $_SESSION['siege'] ;
     $prix = $_SESSION['prix'] ;

    echo"<h2> Détails du vol réservé : </h2>";



   echo "<div class='para'> Votre Vol en direction de <span> $ville_arriv </span> débute le <span> $date_d </span> à  <span> $heure_d </span> <span class='prix'> Prix du billet :  $prix </span> </div>"; 

echo"<h3> Code_Marchant(WAAFI): 5509</h3>";
    
echo "<form>";
    
    // Ajouter un formulaire dans un tableau
    echo "<table border='0' cellspacing = 25>";
     
    // Champ ID_Utilisateur
    echo "<tr><td>ID_Utilisateur :</td><td><input type='text' name='id_utilisateur' value='$username' readonly></td></tr>";
 
    // Champ ID_vol
    echo "<tr><td> numero du Vol :</td><td><input type='number' value='$vol' name='id_vol' readonly></td></tr>";  
 
    // Champ Date de réservation
    $dateReservation = date("Y-m-d");  // Format YYYY-MM-DD
    echo "<tr><td>Date de réservation :</td><td><input type='text' name='date_reservation' value='$dateReservation' readonly></td></tr>";
 
    // Champ numero du siege
    echo "<tr><td>Numero de siege reservé :</td><td><input type='number' min=1 max=90 value=$siege name='num_siege' readonly></td></tr>";
 
      
    // Bouton de soumission
    echo"<br>";
    
 
    echo "</table>";
 
    echo "</form>";

    echo"<a href='https://play.google.com/store/apps/details?id=com.safarifone.waafi&hl=fr&gl=US' target='_blank'>
    <button>EFFECTUER LE PAIEMENT </button>
</a>";

echo"<a href='login_passager.php'> <button>Annuler</button></a>";

}


else {
    // Rediriger si l'username n'est pas défini
    header("Location: login_passager.html");
    exit();
}

?>
         
         <style>

           .form {
            text-align: center;
            margin-left: 415px; 
           
            }

            .couleur{
    background-color: rgba(43, 32, 32, 0.808);
    min-height: 95vh;
    margin: 0vh;
    padding: 0vh;
         }

header{

    color: red;
    font-size:25px ;
    text-decoration: underline;
   
}
            h2{
                color: navy;
                font-size: 20px:  ;
                
            }

             h3{
                color: gold; 
                font-size: 20px;
                text-align: center;
                
            }

            button {
                background-color: chartreuse;
                font-weight:bold;
                font-size: 30px: ;
                margin-left: 140px;
                
            }

            .message{
                  margin-left:50%;
                  margin-bottom:-50%;
                padding-top: -100px;
            color: white;
            text-align: center;
            }

.para{

    font-size: 18px ;
}

.prix{

    color: green;
    padding: 100px;
    font-size: 25px ;
    text-decoration:underline
}
   
span{

font-weight: bold ;
}
        </style>

       

    </div>
    

</div>

    
    </div>
    


    
   
</body>
</html>