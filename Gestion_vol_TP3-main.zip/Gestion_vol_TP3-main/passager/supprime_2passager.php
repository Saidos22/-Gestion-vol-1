<?php
$server='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect($server,$utilisateur,$motpasse,$base);


$passager = $_POST["id"];


$sql = "DELETE FROM passager WHERE id_passager = $passager";


if (mysqli_query($connection,$sql)) {
        echo "passager Supprimer avec succés";
    } 
    
    else {
        echo "Erreur de suppression";
    }
     ?>