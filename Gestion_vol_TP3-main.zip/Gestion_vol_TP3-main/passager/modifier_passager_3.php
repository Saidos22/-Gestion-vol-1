<?php
$SERVER='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect('localhost','root','','gestion des v');

if(!$connection){die("problem de connection".mysqli_connect_erro());}

$id=$_POST['id_passager'];
$nom=$_POST['nom'];
$prenom=$_POST['prenom'];
$adresse=$_POST['Adresse'];   
$num=$_POST['num_tel'];   
$email=$_POST['email']; 
$mdp=$_POST['mdp'];      

$A=("UPDATE passager SET ID_Passager='$id',Nom='$nom',Prenom='$prenom',Adresse='$adresse',Numero_Telephone='$num',Email='$email',Mot_de_Passe='$mdp'  WHERE ID_Passager = '$id'");

if(mysqli_query($connection,$A)){
    echo "modification reussie";
}
else{
    echo "modification non reussie";
}