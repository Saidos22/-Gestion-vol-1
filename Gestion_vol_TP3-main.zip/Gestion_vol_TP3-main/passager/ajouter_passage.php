<?php
$server='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect($server,$utilisateur,$motpasse,$base);


$a = $_POST["id"];           
$b = $_POST["nome"];
$c = $_POST["preno"];
$d = $_POST["adres"];
$e=  $_POST["num"];
$f= $_POST["mail"];
$g= $_POST["passe"];

// SQL query to insert data into the table

$sql = ("INSERT INTO passager VALUES ($a, '$b', '$c', '$d',$e , '$f','$g')");


if (mysqli_query($connection,$sql)) {
        echo "l'ajouter passager";
    } else {
        echo "Erreur d'Ajouter";
    }
     ?>

