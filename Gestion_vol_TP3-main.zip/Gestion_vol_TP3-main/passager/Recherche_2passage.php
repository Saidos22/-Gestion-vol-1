<?php
$server='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect($server,$utilisateur,$motpasse,$base);


$passager = $_POST["id"];


$sql = "SELECT * FROM passager WHERE id_passager = $passager";

$result = mysqli_query($connection,$sql);


echo "<table border=8 cellspacing=0>
<tr>
<th>id_tarif</th>
<th>nom</th>
<th>prenom</th>
<th>Adresse</th>
<th>numero_telephone</th>
<th>email</th>
<th>mot_passe</th>

</tr>
";
echo "<style>

.btnn:hover{
    background: #fff;
    color: #ff0000;
}

.btnn a{
    text-decoration: none;
    color: #000;
    font-weight: bold;
}";
 echo "</style>";
echo "<tr>";

if($result){
    while($row=mysqli_fetch_row($result)){
        echo "<td>".$row[0]."</td>";
        echo "<td>".$row[1]."</td>";
        echo "<td>".$row[2]."</td>";
        echo "<td>".$row[3]."</td>";
        echo "<td>".$row[4]."</td>";
        echo "<td>".$row[5]."</td>";
        echo "<td>".$row[6]."</td>";
        
    }
    echo "</table>";
     echo "<br>";
   echo "<button type= submit class=btnn> <a href='passager.html'> Revenir</button></a>";
}
else{
    echo "affichage echoue";
}
     ?>