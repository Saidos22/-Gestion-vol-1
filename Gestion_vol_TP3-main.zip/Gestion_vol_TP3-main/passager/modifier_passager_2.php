<!DOCTYPE html>
<html>
<head>
	<title>formulaire Passager</title>
</head>
 <style>

.btnn:hover{
    background: #fff;
    color: #ff0000;
}

.btnn a{
    text-decoration: none;
    color: #000;
    font-weight: bold;
}
 </style>
<body> <div class="form">
<center>
<h1>formulaire Passager</h1>


<form method="POST" action="modifier_passager_3.php">
	<table cellpadding="16">
     <?php 
          $serveur="localhost";
          $user="root";
          $secret="";
          $base="gestion des v";

               
          $sum=mysqli_connect($serveur,$user,$secret,$base);
          $num=$_POST["id_passager"];
          $result=mysqli_query($sum,"SELECT * FROM passager WHERE ID_Passager=$num");
	?>
  
          <?php
          	while ($col=mysqli_fetch_row($result)) {

         ?>
		<tr>
			<td><b>id_passager</td>
			<td>
				<?php 

				echo"<input type='text' name='id_passager' value='$col[0]'>";
				 
				 ?>
			</td>
		</tr>
	
		<tr>
			<td><b>nom</td>        
			<td>
				<?php 

				echo"<input type='text' name='nom' value='$col[1]'>";
				 ?>
			</td>
		</tr>
		<tr>
			<td><b>prenom</td>
			<td><?php 

				echo"<input type='text' name='prenom' value='$col[2]'>";
				 ?> </td>
		</tr>
		<tr>
			<td> <b>Adresse</td>
			<td><?php 

				echo"<input type='text' name='Adresse' value='$col[3]'>";
				 ?> </td>
                
		</tr>

		<tr>
			<td> <b>num_tel</td>
			<td><?php 

				echo"<input type='text' name='num_tel' value='$col[4]'>";
				 ?> </td>
                
		</tr>

		<tr>
			<td> <b>email</td>
			<td><?php 

				echo"<input type='email' name='email' value='$col[5]'>";
				 ?> </td>
                
		</tr>

		<tr>
			<td> <b>mot_de_passe</td>
			<td><?php 

				echo"<input type='passaword' name='mdp' value='$col[6]'>";}
				 ?> </td>
                
		</tr>
		
        <tr>
            
            <td><input type="submit" name="envoyer" value="Modifier"></td>
			<td><input type="reset" name="annuler" value="Annuler"></td>
			<td> <button type="reset" class="btnn"><a href="passager.html">Revenir</a></button></td>
			
		</tr>
	</table>
</form>
</body>
</center>
</html>