<?php
$SERVER='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect('localhost','root','','gestion des v');

$Code=$_POST["Modifier"];
$Nom=$_POST["nom_aeroport"];
$Codes=$_POST["Code_aeroport"];
$Emplacement=$_POST["Emplacement_aeroport"];
$Installation=$_POST["Installation_aeroport"];
$A= ("UPDATE aeroport SET nom_aeroport='$Nom' , Code_aeroport='$Codes' , Emplacement_aeroport='$Emplacement' , Installation_aeroport='$Installation' WHERE Code_aeroport='$Code' ");

if(mysqli_query($connection,$A)){
    header("Location: SUPPRESION.html");
}
else{
    header("Location: Error.html");
} ?>