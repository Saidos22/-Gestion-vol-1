<?php
$server='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect($server,$utilisateur,$motpasse,$base);


$id_aeroport = $_POST["id_aeroport"];


$sql = "DELETE FROM aeroport WHERE id_aeroport = $id_aeroport";


if (mysqli_query($connection,$sql)) {
        echo "Aéroport Supprimer avec succés";
    } 
    
    else {
        echo "Erreur de suppression";
    }
     ?>