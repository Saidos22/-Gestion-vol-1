<?php

$Serveur="localhost";
$Utilisateur="root";
$Password="";
$base="gestion des v";

$connexion=mysqli_connect($Serveur,$Utilisateur,$Password,$base);


$a=$_POST['number'];


{
	$Supprime=mysqli_query($connexion,"DELETE FROM aeroport WHERE id_aeroport=$a");

		if ($Supprime==0) {
		echo "Erreur";
	    }else{
		echo "Aeroport ",$a," a etait supprimer de la base de donnees";
		echo "<br>";
	}
}

echo "<style>

.btnn:hover{
    background: #fff;
    color: #ff0000;
}

.btnn a{
    text-decoration: none;
    color: #000;
    font-weight: bold;
}";
 echo "</style>";

echo "<br>
      <button type= submit class=btnn> <a href='BouttonAeroport.html'> Revenir</button></a>
	 ";

?>