<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supprimer un Aéroport</title>
    
</head>
<style>
        body {
            font-family: Arial, sans-serif;
        }

        form {
            max-width: 400px;
            margin: 0 auto;
        }

        label, input {
            display: block;
            margin-bottom: 10px;
        }
    </style>
<body>

    <center><h2>Supprimer un Aéroport</h2></center>

    <center>
        
        <form action="supprimer_aeroport_2.php" method="post">
        <label for="id_aeroport">Sélectionnez l'Aéroport à Supprimer :</label>
        <select name="id_aeroport" required>
          
            <?php
            
            $server='localhost';
            $utilisateur='root';
            $motpasse='';
            $base='gestion des v';

            $connection=mysqli_connect($server,$utilisateur,$motpasse,$base);

            
            $sql = "SELECT id_aeroport, nom_aeroport FROM aeroport";
            $result = mysqli_query($connection,$sql);

           
            while ($row = mysqli_fetch_row($result)) {
                echo "<option value='" . $row[0] . "'>" . $row[1] . "</option>";
            }

        
            ?>
        </select>

        <button type="submit">Supprimer Aéroport</button>
    </form>

    </center>
    
</body>
</html>
