<?php
$server='localhost';
$utilisateur='root';
$motpasse='';
$base='gestion des v';

$connection=mysqli_connect($server,$utilisateur,$motpasse,$base);


$nom_aeroport = $_POST["nom_aeroport"];
$Code_aeroport = $_POST["Code_aeroport"];
$Emplacement_aeroport = $_POST["Emplacement_aeroport"];
$Installation_aeroport = $_POST["Installation_aeroport"];

// SQL query to insert data into the table

$sql = ("INSERT INTO aeroport VALUES (NULL,'$nom_aeroport', '$Code_aeroport', '$Emplacement_aeroport', '$Installation_aeroport')");


if (mysqli_query($connection,$sql)) {
        echo "Aéroport Ajouté";
    } else {
        echo "Erreur d'Ajout";
    }
     ?>